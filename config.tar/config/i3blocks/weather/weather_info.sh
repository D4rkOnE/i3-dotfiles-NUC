#!/bin/sh
echo " $(~/.config/i3blocks/weather/weather.py) "
