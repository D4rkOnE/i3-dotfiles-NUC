NUMBER=$(eval checkupdates | wc -l)
# echo $NUMBER

if [ $NUMBER -ne "0" ]; then
	echo "Pacman: ${NUMBER} updates.  "
fi
