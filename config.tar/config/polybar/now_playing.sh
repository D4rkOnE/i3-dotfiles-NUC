#!/bin/bash

ARTIST=`playerctl metadata --format "{{ artist }}"`
if [[ ! -z "$ARTIST" ]]; then
	TITLE=`playerctl metadata --format "{{ artist }}"`
	echo "Now playing: $ARTIST - ${TITLE}"
else
	echo ""
fi

