NUMBER=$(eval yay -Qua | wc -l)
# echo $NUMBER

if [ $NUMBER -ne "0" ]; then
	echo "AUR: ${NUMBER} updates.  "
fi
