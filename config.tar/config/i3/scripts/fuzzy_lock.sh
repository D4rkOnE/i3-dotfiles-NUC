#!/bin/sh -e

# Take a screenshot
IMAGENAME=/tmp/screen_locked.png
scrot ${IMAGENAME}

# Pixellate it 10x
mogrify -scale 10% -scale 1000% ${IMAGENAME}

# Lock screen displaying this image.
i3lock -i ${IMAGENAME}
rm -rf ${IMAGENAME}
# Turn the screen off after a delay.
sleep 600; pgrep i3lock && xset dpms force off
rm -rf ${IMAGENAME}
