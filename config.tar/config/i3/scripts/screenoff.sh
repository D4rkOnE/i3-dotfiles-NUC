#!/bin/bash
sleep 1; xset dpms force off
